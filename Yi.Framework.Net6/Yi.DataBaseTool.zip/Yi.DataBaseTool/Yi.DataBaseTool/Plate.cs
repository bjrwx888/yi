﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SqlSugar;

namespace Yi.DataBaseTool
{
    [SugarTable("plate")]
    public class Plate
    {
        public int id { get; set; }
        public int is_delete { get; set; }
        public string name { get; set; }
        public string logo { get; set; }
        public string introduction { get; set; }
    }
}
