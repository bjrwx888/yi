﻿// See https://aka.ms/new-console-template for more information
using SqlSugar;
using Yi.DataBaseTool;
using Yi.BBS.Domain.Forum.Entities;
Console.WriteLine("Hello, World!");
SqlSugarClient _db = new SqlSugarClient(new ConnectionConfig()
{
    ConnectionString = "server=106.52.94.217;Database=YIDB-bbs;Uid=root;Pwd=Qz52013142020.;sslMode=None",
    DbType = DbType.MySql,
    IsAutoCloseConnection = true
});

SqlSugarClient _db2 = new SqlSugarClient(new ConnectionConfig()
{
    ConnectionString = "server=106.52.94.217;Database=yi-bbs-dev;Uid=root;Pwd=Qz52013142020.;sslMode=None",
    DbType = DbType.MySql,
    IsAutoCloseConnection = true
});


var discuss = _db.Queryable<Discuss>().Where(x => x.is_delete == 0).ToList();
var article = _db.Queryable<Article>().Where(x => x.is_delete == 0).ToList();
var banner = _db.Queryable<Plate>().Where(x => x.is_delete == 0).ToList();


List<DiscussEntity> discussEntities = new List<DiscussEntity>();
List<ArticleEntity> articleEntities = new List<ArticleEntity>();
List<PlateEntity> plateEntities = new List<PlateEntity>();

Dictionary<int, long> plateDic = new Dictionary<int, long>();

foreach (var b in banner)
{
    var newId = SnowFlakeSingle.Instance.NextId();
    plateDic.Add(b.id, newId);
    plateEntities.Add(new PlateEntity
    {
        Id = newId,
        Introduction = b.introduction,
        Logo = b.logo,
        Name = b.name,
    });
}


Dictionary<int, long> discussDic = new Dictionary<int, long>();
discussDic.Add(0, 0);
foreach (var d in discuss)
{
    if (!plateDic.ContainsKey(d.plateid))
    {
        continue;
    }
    long newId = SnowFlakeSingle.Instance.NextId();
    discussDic.Add(d.id, newId);

    discussEntities.Add(new DiscussEntity
    {
        Id = newId,
        Color = d.color,
        CreationTime = DateTime.Now,
        Introduction = d.introduction,
        Content = d.content,
        Title = d.title,
        PlateId = plateDic[d.plateid],
    });
}

Dictionary<int, long> articleDic = new Dictionary<int, long>();
//第一级，先替换主题id
foreach (var a in article)
{

    //代表需要递归的子文章
    if (a.discussid != 0)
    {
        if (!discussDic.ContainsKey(a.discussid))
        {
            continue;
        }
    }

    long newId = SnowFlakeSingle.Instance.NextId();
    articleDic.Add(a.id, newId);
    articleEntities.Add(new ArticleEntity
    {
        Id = newId,
        Content = a.content,
        DiscussId = discussDic[a.discussid],
        Name = a.name,

        //先保持不变，二次遍历
        ParentId = a.articleid
    });
}

articleDic.Add(0, 0);
foreach (var a in articleEntities)
{
    if (articleDic.ContainsKey((int)a.ParentId))
    {
        a.ParentId = articleDic[(int)a.ParentId];
    }
}
foreach (var a in articleEntities)
{
    //代表子文章
    if (a.DiscussId == 0)
    {
        //获取上一级
        var a1 = articleEntities.FirstOrDefault(x => x.Id == a.ParentId);
        if (a1 == null)
        {
            continue;
        }
        if (a1.DiscussId != 0)
        {
            a.DiscussId = a1.DiscussId;
            continue;
        }
        var a2 = articleEntities.FirstOrDefault(x => x.Id == a1.ParentId);
        if (a2 == null)
        {
            continue;
        }
        if (a2.DiscussId != 0)
        {
            a.DiscussId = a2.DiscussId;
            continue;
        }
        var a3 = articleEntities.FirstOrDefault(x => x.Id == a2.ParentId);
        if (a3== null)
        {
            continue;
        }
        if (a3.DiscussId != 0)
        {
            a.DiscussId = a3.DiscussId;
            continue;
        }
        var a4 = articleEntities.FirstOrDefault(x => x.Id == a3.ParentId);
        if (a4 == null)
        {
            continue;
        }
        if (a4.DiscussId != 0)
        {
            a.DiscussId = a4.DiscussId;
            continue;
        }
    }
}



_db2.Ado.UseTran(() =>
{
    Console.WriteLine("完成");
    _db2.Insertable(plateEntities).ExecuteCommand();
    Console.WriteLine("完成1");
    _db2.Insertable(discussEntities).ExecuteCommand();
    Console.WriteLine("完成2");
    _db2.Insertable(articleEntities).ExecuteCommand();
    Console.WriteLine("完成3");
});

_db.Close();
_db2.Close();
Console.ReadKey();


