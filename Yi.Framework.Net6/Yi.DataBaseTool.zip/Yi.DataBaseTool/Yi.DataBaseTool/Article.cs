﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SqlSugar;

namespace Yi.DataBaseTool
{
    [SugarTable("article")]
    public class Article
    {
        public int id { get; set; }
        public int is_delete { get; set; }
        public string content { get; set; }
        public string name { get; set; }

        public int discussid { get; set; }


        public int articleid { get; set; }
    }
}
