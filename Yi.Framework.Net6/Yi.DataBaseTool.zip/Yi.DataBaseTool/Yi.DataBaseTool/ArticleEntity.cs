﻿
using SqlSugar;


namespace Yi.BBS.Domain.Forum.Entities
{
    [SugarTable("Article")]
    public class ArticleEntity 
    {
        [SugarColumn(IsPrimaryKey = true)]
        public long Id { get; set; }
        public bool IsDeleted { get; set; }

        public string Content { get; set; }
        public string Name { get; set; }


        public long DiscussId { get; set; }

        public long ParentId { get; set; }

        [SugarColumn(IsIgnore =true)]

        public List<ArticleEntity> Children { get; set; }
    }
}
